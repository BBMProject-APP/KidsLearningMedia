// IMPORT SCREEN FUNCTIONS
// ==========================
import { loadHomeScreen } from "./screens/Home.js";
import { loadAlphabetScreen } from "./screens/Alphabet.js";
import { loadQuizScreen } from "./screens/Quiz.js";
import { loadAnimalScreen } from "./screens/Animals.js";
import { loadFruitScreen } from "./screens/Fruits.js";
import { loadObjectScreen } from "./screens/Objects.js";
import { loadCoverScreen } from "./screens/Cover.js";



// ===================================================
// PLAY INTRO MUSIC (Hanya dimainkan sekali pada klik pertama)
// ===================================================
function playIntroMusicOnce() {
    const music = new Audio("./app/audio/intro.mp3");
    music.volume = 1;
    music.loop = false; 

    // Gunakan event listener terpisah, bukan document.body.onclick, yang akan dilepas
    const bodyElement = document.body;

    // Fungsi handler yang hanya akan dipanggil sekali
    const musicStarter = () => {
        music.play().catch(() => {});
        // Hapus event listener ini setelah berhasil memutar
        bodyElement.removeEventListener('click', musicStarter);
        bodyElement.removeEventListener('touchstart', musicStarter); 
        // Tambahkan touchstart untuk mobile
    };

    // Pasang listener untuk klik dan sentuhan
    bodyElement.addEventListener('click', musicStarter);
    bodyElement.addEventListener('touchstart', musicStarter);
}

// ===================================================
// UNIVERSAL AUDIO PLAYER (DI-EXPORT untuk Modul Quiz)
// ===================================================

/**
 * Memainkan file audio berdasarkan path yang diberikan.
 * @param {string} path - Path ke file audio (misal: '../app/audio/cat.mp3')
 */
export function playAudio(path) {
    if (!path) {
        console.error("Audio path is missing.");
        return;
    }
    try {
        const audio = new Audio(path);
        audio.volume = 1; // Volume diatur 1 (maksimal)
        audio.play().catch(e => {
            console.warn("Audio playback blocked, requires user interaction:", e);
        });
    } catch (error) {
        console.error("Error creating audio object:", error);
    }
}
// ===================================================
// UNIVERSAL ZOOM SYSTEM (Menggunakan Delegasi Event + Timer)
// ===================================================
function setupUniversalZoom() {
    const bodyElement = document.body;

    // Simpan Timer ID agar bisa dibatalkan jika overlay diklik
    let zoomTimerId = null; 
    const ZOOM_DURATION_MS = 2500; // 2.5 Detik

    // 1. Buat overlay HANYA SEKALI
    let overlay = document.getElementById("zoom-overlay");
    if (!overlay) {
        overlay = document.createElement("div");
        overlay.id = "zoom-overlay";
        overlay.className = "image-zoom-overlay";
        overlay.style.display = "none";
        bodyElement.appendChild(overlay);

        // Klik overlay → tutup zoom (Listener ini dipasang sekali)
        overlay.addEventListener("click", () => {
            overlay.style.display = "none";
            overlay.innerHTML = "";
            
            // BATALKAN TIMER JIKA DITUTUP MANUAL
            if (zoomTimerId) {
                clearTimeout(zoomTimerId);
                zoomTimerId = null; // Reset ID
            }
        });
    }

    // 2. Pasang Listener HANYA PADA BODY/APP (Delegasi)
    bodyElement.addEventListener("click", (event) => {
        let img = event.target;

        // Cek apakah target yang diklik adalah gambar yang valid
        if (img.tagName === 'IMG' && !img.classList.contains("no-zoom")) {
            
            // Hapus timer lama jika ada (jika user mengklik cepat berkali-kali)
            if (zoomTimerId) {
                clearTimeout(zoomTimerId);
            }
            
            // Play pop sound
            const pop = new Audio("./app/audio/pop.mp3");
            pop.volume = 1;
            pop.play().catch(() => {});

            // Tampilkan overlay + gambar besar
            overlay.innerHTML = `<img src="${img.src}" />`;
            overlay.style.display = "flex";

            // ===============================================
            // KODE BARU: TIMER OTOMATIS
            // ===============================================
            zoomTimerId = setTimeout(() => {
                // Sembunyikan overlay setelah 2.5 detik
                overlay.style.display = "none";
                overlay.innerHTML = "";
                zoomTimerId = null; // Reset ID setelah selesai
            }, ZOOM_DURATION_MS); 
        }
    });
}
// ===================================================
// QUIZ BACKGROUND MUSIC CONTROL
// ===================================================

let currentQuizMusic = null; // Objek Audio yang sedang aktif

/**
 * Menghentikan musik kuis yang sedang berjalan.
 */
export function stopQuizMusic() {
    if (currentQuizMusic) {
        currentQuizMusic.pause(); // Hentikan pemutaran
        currentQuizMusic.currentTime = 0; // Kembalikan ke awal
        currentQuizMusic = null; // Hapus referensi
    }
}

/**
 * Memulai musik kuis baru.
 * @param {string} path - Path ke file musik.
 */
export function startQuizMusic(path = "./app/audio/quizmusic.mp3") {
    // 1. Pastikan musik lama dihentikan
    stopQuizMusic(); 

    // 2. Buat dan mainkan musik baru
    currentQuizMusic = new Audio(path);
    currentQuizMusic.loop = true;
    currentQuizMusic.volume = 0.5;

    // Mulai musik setelah sedikit penundaan untuk memastikan DOM siap
    setTimeout(() => {
        currentQuizMusic.play().catch(() => {
            console.warn("Quiz music blocked.");
        });
    }, 200);
}
// ===========================
// ROUTER NAVIGATION
// ===========================
export function navigate(screen) {
    screen = screen.toLowerCase();

    if (screen === "home") {
        stopQuizMusic(); // Berhenti saat kembali ke Home
        loadHomeScreen();
        return;
    }
    if (screen === "cover") loadCoverScreen();
    if (screen === "home") loadHomeScreen();
    if (screen === "alphabet") loadAlphabetScreen();
    if (screen === "quiz") loadQuizScreen();
    if (screen === "animals") loadAnimalScreen();
    if (screen === "fruits") loadFruitScreen();
    if (screen === "objects") loadObjectScreen();

    // Kita tidak perlu memanggilnya lagi karena sudah menggunakan Delegasi Event
}

window.navigate = navigate;


// ===========================
// START APP
// ===========================

document.addEventListener('DOMContentLoaded', () => {
    // 1. Setup zoom system secara universal
    setupUniversalZoom(); // Cukup dipanggil sekali di sini!
    
    // 2. Play intro music (akan menunggu klik user pertama)
    playIntroMusicOnce();
    
    // 3. Load halaman utama
    loadHomeScreen();
    // 4. baca halaman cover
    loadCoverScreen();
});