import { navigate } from "../app.js";

export function loadAlphabetScreen() {
    const app = document.getElementById("app");

    // Generate A-Z images
    let letters = "";
    for (let c = 65; c <= 90; c++) {
        const L = String.fromCharCode(c);
        letters += `
            <img 
                src="./app/svg/letter-${L}.svg" 
                class="letter"
                onclick="playSound('${L}')"
            />
        `;
    }

    app.innerHTML = `
        <div class="alphabet-screen">
            <h1>Knowing Letters</h1>

            <button onclick="navigate('home')" class="back-btn">⬅ Back</button>

            <div class="letters">${letters}</div>
        </div>
    `;

    // Play sound
    window.playSound = (L) => {
        const audio = new Audio(`./app/audio/${L}.mp3`);
        audio.play();
    };
}
