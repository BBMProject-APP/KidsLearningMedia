export function loadQuizScreen() {
    const app = document.getElementById("app");

    // === 🔊 Musik Background Quiz (global, loop) ===
    let quizMusic = new Audio("./app/audio/quizmusic.mp3");
    quizMusic.loop = true;
    quizMusic.volume = 0.5;

    // Mulai musik setelah DOM berubah, supaya tidak diblokir browser
    setTimeout(() => {
        quizMusic.play().catch(() => {});
    }, 200);

    // === Data Huruf ===
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
    let target = letters[Math.floor(Math.random() * letters.length)];

    // === 🔊 Putar suara instruksi + huruf ===
    function playInstructionWithLetter(letter) {
        const intro = new Audio("./app/audio/quiz.mp3");
        intro.volume = 1;

        intro.onended = () => {
            const letterSound = new Audio(`./app/audio/${letter}.mp3`);
            letterSound.volume = 1;
            letterSound.play().catch(() => {});
        };

        intro.play().catch(() => {});
    }

    // === REFRESH QUIZ ===
    function refreshQuiz() {
        target = letters[Math.floor(Math.random() * letters.length)];

        let html = `<h2><span style="font-size:45px;">${target}</span></h2>`;

        // Tombol kembali (stop musik)
        html += `<button id="backBtn">⬅ Back</button>`;

        html += `<div class="letters">`;
        letters.forEach((L) => {
            html += `<img src="./app/svg/letter-${L}.svg" onclick="check('${L}')" />`;
        });
        html += `</div>`;

        app.innerHTML = html;

        // Tombol kembali: stop musik lalu navigate
        document.getElementById("backBtn").addEventListener("click", () => {
            quizMusic.pause();
            quizMusic.currentTime = 0;
            navigate("home");
        });

        // Putar instruksi dan suara huruf target
        playInstructionWithLetter(target);
    }

    // === CEK JAWABAN ===
    window.check = (L) => {
        if (L === target) {
            new Audio("./app/audio/correct.mp3").play();
        } else {
            new Audio("./app/audio/wrong.mp3").play();
        }

        setTimeout(refreshQuiz, 800);
    };

    refreshQuiz();
}
