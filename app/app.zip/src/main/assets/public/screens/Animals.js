import { navigate, playAudio, startQuizMusic } from "../app.js"; // IMPORT startQuizMusic

export function loadAnimalScreen() {
    const app = document.getElementById("app");

    const items = [
        "cat", "dog", "cow", "lion", "tiger",
        "rabbit", "horse", "sheep", "elephant", "monkey"
    ];

    let target = items[Math.floor(Math.random() * items.length)];

    // FUNGSI GLOBAL REPLAY: Memutar ulang audio target saat ini.
    window.replayTaskAudio = () => {
        // Path Audio Target disesuaikan kembali ke format yang Anda gunakan
        playAudio(`./app/audio/${target}.mp3`);
    };

    function render() {
        let html = `
            <div class="animal-screen">
                <h1>Animals Quiz 🐾</h1>
                <h3>
                    <b>${target.toUpperCase()}</b>
                    <button 
                        onclick="replayTaskAudio()" 
                        class="replay-audio-btn no-zoom"
                    >
                        🔊
                    </button>
                </h3>
                
                <button onclick="navigate('home')">⬅ Back</button>
                <div class="animal-list">
        `;

        items.forEach((x) => {
            // Path Gambar disesuaikan kembali ke format yang Anda gunakan
            html += `<img class="quiz-img" src="./app/animals/${x}.png" onclick="check('${x}')">`;
        });

        html += `</div></div>`; 
        app.innerHTML = html;
        
        // PANGGILAN AUDIO AWAL
        playAudio(`./app/audio/${target}.mp3`);
    }

    window.check = (x) => {
        if (x === target) {
            // Path Audio SFX disesuaikan kembali ke format yang Anda gunakan
            playAudio("./app/audio/correct.mp3");
        } else {
            // Path Audio SFX disesuaikan kembali ke format yang Anda gunakan
            playAudio("./app/audio/wrong.mp3");
        }

        setTimeout(() => {
            target = items[Math.floor(Math.random() * items.length)];
            render();
        }, 1000);
    };

    render();

startQuizMusic(); // Secara default akan memutar quizmusic.mp3
}