import { navigate, playAudio, startQuizMusic } from "../app.js"; // IMPORT startQuizMusic

export function loadFruitScreen() {
    const app = document.getElementById("app");

    // GANTI DAFTAR BUAH INI SESUAI DENGAN FILE ANDA
    const items = [
        "apple", "banana", "orange", "grape", "watermelon",
        "kiwi", "mango", "pear", "strawberry", "lemon" 
    ];

    let target = items[Math.floor(Math.random() * items.length)];

    // FUNGSI GLOBAL REPLAY: Memutar ulang audio target saat ini.
    window.replayTaskAudio = () => {
        playAudio(`./app/audio/${target}.mp3`);
    };

    function render() {
        let html = `
            <div class="fruit-screen">
                <h1>Fruits Quiz 🍎</h1>
                <h3>
                    <b>${target.toUpperCase()}</b>
                    <button 
                        onclick="replayTaskAudio()" 
                        class="replay-audio-btn no-zoom"
                    >
                        🔊
                    </button>
                </h3>
                
                <button onclick="navigate('home')">⬅ Back</button>
                <div class="animal-list"> `;

        items.forEach((x) => {
            // Path Gambar: "./app/fruits/nama_buah.png"
            html += `<img class="quiz-img" src="./app/fruits/${x}.png" onclick="check('${x}')">`;
        });

        html += `</div></div>`; 
        app.innerHTML = html;
        
        // PANGGILAN AUDIO AWAL
        playAudio(`./app/audio/${target}.mp3`);
    }

    window.check = (x) => {
        if (x === target) {
            playAudio("./app/audio/correct.mp3");
        } else {
            playAudio("./app/audio/wrong.mp3");
        }

        setTimeout(() => {
            target = items[Math.floor(Math.random() * items.length)];
            render();
        }, 1000);
    };

    render();

startQuizMusic(); // Secara default akan memutar quizmusic.mp3
}