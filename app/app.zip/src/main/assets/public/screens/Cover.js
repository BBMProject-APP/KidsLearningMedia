export function loadCoverScreen() {
    const app = document.getElementById("app");

    app.innerHTML = `
        <div class="cover-container">
            <div id="coverLogo" class="cover-logo hidden">
                <img src="./app/cover/logo.png" class="cover-img" />
            </div>

            <h1 id="coverTitle" class="cover-title hidden">Kids Learning</h1>

        
            <p id="coverDesc" class="cover-desc hidden">
                Let's learn and play! Discover the world of letters, cute animals, tasty fruits, and colorful objects with fun interactive challenges.
            </p>

            <button id="nextBtn" class="next-btn hidden">NEXT ➜</button>
        </div>
    `;

    // ----- AUDIO -----
    const popSound = new Audio("./app/audio/pop.mp3");

    // ----- ANIMASI LOGO -----
    setTimeout(() => {
        const logo = document.getElementById("coverLogo");
        if (logo) {
            logo.classList.remove("hidden");
            logo.classList.add("bounceIn");
            popSound.currentTime = 0;
            popSound.play().catch(e => console.log("Audio play diblokir browser sebelum interaksi"));
        }
    }, 300);

    // ----- ANIMASI TITLE -----
    setTimeout(() => {
        const title = document.getElementById("coverTitle");
        if (title) {
            title.classList.remove("hidden");
            title.classList.add("bounceIn");
            popSound.currentTime = 0;
            popSound.play().catch(e => console.log("Audio play diblokir browser sebelum interaksi"));
        }
    }, 900);

    // ----- ANIMASI DESKRIPSI (Muncul setelah Title) -----
    setTimeout(() => {
        const desc = document.getElementById("coverDesc");
        if (desc) {
            desc.classList.remove("hidden");
            desc.classList.add("fadeIn"); // Ikut efek memudar pelan
        }
    }, 1300);

    // ----- BUTTON MUNCUL -----
    setTimeout(() => {
        const btn = document.getElementById("nextBtn");
        if (btn) {
            btn.classList.remove("hidden");
            btn.classList.add("fadeIn");
        }
    }, 1800);

    // ----- Arahkan ke Home -----
    const nextButton = document.getElementById("nextBtn");
    if (nextButton) {
        nextButton.onclick = () => {
            navigate("home");
        };
    }
}