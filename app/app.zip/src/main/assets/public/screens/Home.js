import { navigate } from "../app.js";

export function loadHomeScreen() {
    const app = document.getElementById("app");

    app.innerHTML = `
        <div class="home-screen">
            <h1>KIDS LEARNING APP 🎉</h1>

            <button onclick="navigate('alphabet')">🎵 Letters</button>
            <button onclick="navigate('quiz')">🔤 Letters Quiz</button>
            <button onclick="navigate('animals')">🐶 Animals Quiz</button>
            <button onclick="navigate('fruits')">🍎 Fruits Quiz</button>
            <button onclick="navigate('objects')">🧸 Objects Quiz</button>

            <br>
            <button id="btn-exit" class="btn-exit">🚪 EXIT</button>
        </div>
    `;

    // ----- LOGIKA UNTUK MENUTUP APLIKASI DI ANDROID (VERSI AMPUH) -----
    const exitButton = document.getElementById("btn-exit");
    if (exitButton) {
        exitButton.onclick = () => {
            // Taktik 1: Cek fungsi exit bawaan Capacitor/Cordova global
            if (window.navigator && navigator.app && navigator.app.exitApp) {
                navigator.app.exitApp(); 
            } 
            // Taktik 2: Senjata pamungkas jika Taktik 1 tidak merespon
            else if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
                window.Capacitor.Plugins.App.exitApp();
            }
            // Taktik 3: Pengaman jika dites di browser laptop
            else {
                alert("Application Exit: This feature is only available on native Android devices.");
            }
        };
    }
}