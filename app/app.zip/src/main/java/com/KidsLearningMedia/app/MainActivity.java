package com.KidsLearningMedia.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
